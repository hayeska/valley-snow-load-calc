# Valley Snow Load Calculator - Backup 2024-12-24

This backup contains the complete Valley Snow Load Calculator program as of December 24, 2024.

## Files Included:
- main.py - Main application entry point
- gui_interface.py - Complete Tkinter GUI with all calculations
- drift_calculator.py - ASCE 7-22 drift calculations
- beam_design.py - Valley beam analysis and design
- slope_factors.py - Roof slope factor calculations
- geometry.py - Roof geometry calculations
- constants.py - Program constants and defaults
- validation.py - Input validation functions
- balanced_load.py - Balanced snow load calculations
- jack_rafter_module.py - Jack rafter analysis
- asce7_22_reference.py - ASCE 7-22 reference materials

## Program Features:
- Complete ASCE 7-22 Section 7.6.1 compliance
- Unbalanced snow load analysis for hip/gable roofs
- Valley drift calculations with intersecting gables
- Professional beam design with ASD load combinations
- Comprehensive PDF report generation
- Interactive GUI with real-time validation
- Save/load project functionality

## Key Defaults (as of backup):
- Ground snow load: User input (default 50 psf)
- Importance factor: 1.0 (Risk Category II)
- Beam width: 3.5 inches
- Dead load: 15 psf
- Various other engineering defaults

## To Restore:
1. Copy all files back to the main directory
2. Ensure Python 3.8+ is installed
3. Install required packages: reportlab (for PDF generation)
4. Run: python main.py

## Backup Integrity:
✅ All Python source files backed up
✅ Complete functionality preserved
✅ All calculations and features intact
✅ Ready for restoration if needed

Created: December 24, 2024
Backup Version: Production-Ready ASCE 7-22 Compliant
